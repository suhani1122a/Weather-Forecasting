Step 1. Press Shift + Right click on the Extacted folder and select "Open Powershell Window here."
Step 2. Run the following Command:
		:pip install -r requirements.txt
Step 3. In the same power shell window run the following command:
		:python main.py 